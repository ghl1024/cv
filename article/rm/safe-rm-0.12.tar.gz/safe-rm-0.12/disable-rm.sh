#!/bin/bash

Date=`date +%Y-%m-%d-%H_%M_%S`
mv /usr/local/bin/rm /usr/local/bin/rm.$Date
cp ./safe-rm /usr/local/bin/rm
cp /etc/profile /etc/profile-$Date 
cat >> /etc/profile <<\EOF
#disabled rm delete some directory
export PATH=/usr/local/bin:/bin:/usr/bin:$PATH
EOF
cat > /etc/safe-rm.conf <<\EOF
/
/bin
/boot
/data
/dev
/etc
/home
/lib
/lib64 
/media
/mnt
/opt
/proc
/root
/rsync
/run
/sbin
/sys
/tmp
/usr
/var
EOF
