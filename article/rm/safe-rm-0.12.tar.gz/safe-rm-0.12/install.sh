#!/bin/bash

Date=`date +%Y-%m-%d-%H_%M_%S`
cp /etc/profile /etc/profile-$Date 
cat >> /etc/profile <<\EOF
export PATH=/usr/local/bin:/bin:/usr/bin:$PATH
EOF
source /etc/profile
cat > /etc/safe-rm.conf <<\EOF
/
/bin
/boot
/data
/dev
/etc
/home
/lib
/lib64 
/media
/mnt
/opt
/proc
/root
/rsync
/run
/sbin
/sys
/tmp
/usr
/var
EOF
